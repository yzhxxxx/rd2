public class MethodTest{
    public static void main(String[] args){
        MethodTest.methodDemo();
    }
    
    public static void methodDemo(){
        System.out.println("Hello Shiyanlou");
    }
}