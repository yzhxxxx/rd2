import java.util.Scanner;


public class ContrastString{

	public boolean contrast(String a,String b) {
		if(a==null||b==null){
            return false;
        }
        if(a.length()!=b.length()){
            return false;
        }
        return a.equals(b);
	}

    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        String a = in.next();
        String b = in.next();
        ContrastString cs = new ContrastString();
        String result = cs.contrast(a,b)?"相同":"不同";
        System.out.println(result);
        in.close();
    }
}