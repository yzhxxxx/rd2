public class VarTest{

    public static void main(String args[]){
        int aaa;
        aaa = 2019;
        System.out.println(aaa);
    }
}