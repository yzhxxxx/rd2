public class FinalVar{

    public static void main(String args[]){
        final double e = 2.718;
        System.out.println(e);
    }
}