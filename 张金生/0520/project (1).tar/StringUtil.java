import java.util.Scanner;


public class StringUtil{

	public String strip(String tmp) {
		int i = tmp.indexOf(' ');
		//System.out.println(i);
		if(i<0) {
			return tmp;
		}else {
			return tmp.substring(0, i)+strip(tmp.substring(i+1,tmp.length()));
		}
	}

    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        String s = in.nextLine();
        System.out.println(new StringUtil().strip(s));
        in.close();
    }
}