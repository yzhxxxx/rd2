public class FinalVar{

    public static void main(String args[]){
        final double E = 2.718;
        System.out.println(E);
    }
}