public class StringTest{

    public static void main(String args[]){
        String s = "abcdefgabcdefg";
        System.out.println(s);
        System.out.println(s.charAt(6));
        System.out.println(s.lastIndexOf("ab"));
    }
}